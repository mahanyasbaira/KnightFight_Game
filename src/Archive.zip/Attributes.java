public interface Attributes {
    int getArmor();         
    int getMaxHP();         
    DiceType getDamageDie();
    int getHitModifier();   
}