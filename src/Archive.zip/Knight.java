public class Knight extends MOB {
    private Fortune activeFortune;
    protected int id;
    protected int xp;

    public Knight(int id, String name, int maxHP, int armor, 
                 int hitModifier, DiceType damageDie, int xp) {
        super(name, maxHP, armor, hitModifier, damageDie);
        this.id = id;
        this.xp = xp;
    }

    public void addXP(int xp) {
        this.xp += xp;
    }

    public Fortune getActiveFortune() {
        return activeFortune;
    }

    public Integer getId() {
        return id;
    }

    public int getXP() {
        return xp;
    }

    public void setActiveFortune(Fortune fortune) {
        this.activeFortune = fortune;
    }

    @Override
    public int getArmor() {
        int baseArmor = super.getArmor();
        return activeFortune != null ? baseArmor + activeFortune.getArmor() : baseArmor;
    }

    @Override
    public int getMaxHP() {
        int baseHP = super.getMaxHP();
        return activeFortune != null ? baseHP + activeFortune.getMaxHP() : baseHP;
    }

    @Override
    public DiceType getDamageDie() {
        if (activeFortune != null && activeFortune.getDamageDie() != null) {
            return activeFortune.getDamageDie();
        }
        return super.getDamageDie();
    }

    @Override
    public int getHitModifier() {
        int baseMod = super.getHitModifier();
        return activeFortune != null ? baseMod + activeFortune.getHitModifier() : baseMod;
    }

    public String toCSV() {
        return String.format("%d,%s,%d,%d,%d,%s,%d",
            id, 
            getName(), 
            getMaxHP(), 
            getArmor(), 
            getHitModifier(),
            getDamageDie() != null ? getDamageDie().name() : "null",
            xp);
    }

    @Override
    public String toString() {
        return String.format(
            "+============================+\n" +
            "| %-26s |\n" +
            "| id: %-22d |\n" +
            "|                            |\n" +
            "| Health: %-4d    XP: %-7d |\n" +
            "|  Power: %-4s    Armor: %-4d |\n" +
            "+============================+",
            getName(), 
            id, 
            getMaxHP(), 
            xp, 
            getDamageDie() != null ? getDamageDie().name() : "-", 
            getArmor()
        );
    }
}